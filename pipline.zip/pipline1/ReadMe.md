

## To build and run the docker container 
build image `docker build --tag nginx-python .`  

Run the container `docker run -d -p 80:80 nginx-python`

Now go to localhost:80, then you will see the index.html content 



## Jenkins 
To launch a local Jenkins server: 
`docker run -p 8080:8080 -p 50000:50000 -d -v jenkins_home:/var/jenkins_home jenkins/jenkins:lts` 

Then set up the workflow and link it with the GitHub repo, set an intervel to auto fetch the new commits on GitHub repo. 

A Jenkinsfile is provided, to build a test docker image and run the docker tests in it. 



## To run docker test 
GitHub workflow is set up, every time push to the dev branch, GitHub Action run the docker test

Workflow file location: ./github/workflow/main.xml 

1. check if nginx is installed properly by listing the version informaiton 
2. Check if the config file is proivded by checking the config file existence. 



## Branch protection & PR review gates 
Branch protection & PR review happends on GitHub, hard to give a demo in the static repo. 

Bascially, a branch protection rule has been set up so that to enable "require a pull request before merging" and disable "force pushes" & "branch deletions"
