import psutil

while True:
    print('The CPU usage is(%): ', psutil.cpu_percent(3))
    print('RAM memory usage is(%):', psutil.virtual_memory()[2])