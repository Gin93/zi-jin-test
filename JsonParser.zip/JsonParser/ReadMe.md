# JSON Praser 

A JSON parser written in Python.  Take a JSON file as input and return an object of the custimized data strcture. 

At this moment, Candy is supported. 

An example JSON file is supported, see ./example.json 

Files: 
- candy.py: The file defines the Candy class 
- json_parser.py: The main file, defines the parser. 
- tests.py: Define some units and functional tests. 


## Example json file 
```json
{
    "price": "3.14",
    "ingredients": [
        {
            "name": "protein0",
            "category": "natural"
        },
        {
            "name": "protein1",
            "category": "natural"
        },
        {
            "name": "protein2",
            "category": "artifical"
        },
        {
            "name": "protein3",
            "category": "artifical"
        }
    ]
}
```


## Test 
Run `python3 tests.py` in terminal  

## Run 

### To run it without Docker: 

To run the demo: `python3 json_parser.py` You will see a Candy object is returned. 


To use it as a moudle: 
```py
from json_parser import JsonParser
from candy import Candy
candy = JsonParser(path,Candy) 
```

### To run it with Docker: 

Build: `docker build --tag python-json-praser .`

Run: `docker run python-json-praser` 

If want to run the test, can get into the running docker container bash, then run `python3 tests.py` 

