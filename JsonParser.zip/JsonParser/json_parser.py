import json 
from typing import TypeVar 
from candy import Candy , NaturalIngredient , ArtificialIngredient

def _CandyParser(json_data):
    '''
    Parse a json loaded dictionary data to a Candy instance. 
    Private function. Called by JsonParser(path: str, cls: T) -> T: 

        Parameters: 
            json_data (dict) : the dictionary data loaded by json.load() 

        Return: 
            An instance of Candy 
    '''

    # At this moment, only takes "natural" and "atrifical" ingredient. 
    # When more types of ingredient are needed, create a new subclass of Ingredient then register here. 
    supported_ingredients = {
        "natural" : NaturalIngredient,
        "artifical" : ArtificialIngredient
    }

    try: 
        price = json_data['price']
    except KeyError: 
        raise KeyError("\n\nKeyError. Price tag is not found in the JSON file\n\n") 

    try:
        ingredients = json_data['ingredients']
    except KeyError:
        raise KeyError("\n\nKey Error. Ingredients tag is not found in the JSON file\n\n")
    
    ingredient_lst = [] 
    for ingredient in ingredients: 
        try: 
            name , type_ = ingredient['name'] , ingredient['category']
        except: 
            raise Exception("Error Ingredient format error. Should consists of two fields, name & category")
        if type_ not in supported_ingredients:
            raise Exception("Error, the ingredient type is not supported. Supported types are: {}".format(supported_ingredients.keys()))
        ingredient_lst.append(supported_ingredients[type_](name))

    return Candy(price,ingredient_lst)





T = TypeVar('T')
def JsonParser(path: str, cls: T) -> T: 
    '''
    Entry function for this moudle 

    Load a JSON file, and parse it based on the given data strcture type. 

        Parameters: 
            path (str) : the path of the JSON file 
            cls (custimzed data type, e.g Candy) : the data strcture type you want the function to parse to. 

        Return: 
            An object of the input cls. 
    '''

    # At this moment, only takes Candy object 
    # When more types object are needed, for example, a new type "Fruit", create a new class & a parser function,  
    #   then register the parser function here.
    supported_parsers = {
        Candy: _CandyParser
    }

    if cls not in supported_parsers: 
            raise Exception("{} is not supported by the parsers. The related class and parser should be defined and registered properly".format(str(cls)))
    
    with open(path) as f: 
        json_data = json.load(f)

    return supported_parsers[cls](json_data) 


if __name__ == "__main__":

    # a demo to use the parser. 

    path = "./example.json" # json file 
    candy = JsonParser(path,Candy) # parse the json file, need to input the data structure type 
    print("A candy object has been parsed successfully: \n")
    print(candy)

