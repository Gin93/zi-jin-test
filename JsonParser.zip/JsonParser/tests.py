import unittest

from json_parser import JsonParser , _CandyParser
from candy import Candy, NaturalIngredient, ArtificialIngredient


class MyTestCase1(unittest.TestCase):
    '''
    Some unit tests
        All are successful cases
    '''

    def test_feature_one(self):
        # Candy can be created as expected.
        candy = Candy(1.1, [NaturalIngredient("Protein1"),
                      ArtificialIngredient("protein2")])
        self.assertTrue(isinstance(candy, Candy), "Return type is not Candy")

    def test_feature_two(self):
        # _candyparser can parse dict data correctly 
        data = {
            "price": "3.14",
            "ingredients": [
                {
                    "name": "protein0",
                    "category": "natural"
                },
                {
                    "name": "protein1",
                    "category": "natural"
                },
                {
                    "name": "protein2",
                    "category": "natural"
                },
                {
                    "name": "protein3",
                    "category": "natural"
                }
            ]
        }
        candy = _CandyParser(data)
        self.assertTrue(isinstance(candy, Candy), "Return type is not Candy")


class MyTestCase2(unittest.TestCase):
    '''
    Some high level tests. 
        Fail cases. 
        Parse some JSON files directly. 
    '''

    def test_feature_one(self):
        # Wrong price tag
        with self.assertRaises(KeyError):
            JsonParser("./test_data/wrong1.json", Candy)

    def test_feature_two(self):
        # Wrong ingredients tag
        with self.assertRaises(KeyError):
            JsonParser("./test_data/wrong2.json", Candy)

    def test_feature_three(self):
        # Wrong ingredients(name) tag
        with self.assertRaises(Exception):
            JsonParser("./test_data/wrong3.json", Candy)

    def test_feature_four(self):
        # Wrong ingredients(category) tag
        with self.assertRaises(Exception):
            JsonParser("./test_data/wrong4.json", Candy)

    def test_feature_five(self):
        # Wrong ingredients category value
        with self.assertRaises(Exception):
            JsonParser("./test_data/wrong5.json", Candy)


class MyTestCase3(unittest.TestCase):
    '''
    One high level test. 
        Parse the demo json file. 
        Expected to be succesful! 
    '''

    def test_feature_one(self):
        candy = JsonParser("./example.json", Candy)
        self.assertTrue(isinstance(candy, Candy), "Return type is not Candy")


if __name__ == '__main__':
    unittest.main()
