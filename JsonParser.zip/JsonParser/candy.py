from typing import List
import abc 

class _Ingredient(abc.ABC):
    '''
    A class to represent an ingredient. 
        This class is meant to be subclassed. 

    Attributes: 
    ----------
    name: str 
        The name of the ingredient
    '''

    def __init__(self, name: str) -> None:
        self.name = name 
        super().__init__()

    def __str__(self) -> str:
        return self.name 

class NaturalIngredient(_Ingredient):
    '''
    A subclass of Ingredient. 
        To represent the natural ingredient
    '''

    def __str__(self) -> str:
        return self.name + "(Natural)"

class ArtificialIngredient(_Ingredient):
    '''
    A subclass of Ingredient. 
        To represent the artificial ingredient
    '''

    def __str__(self) -> str:
        return self.name + "(Artificial)"

class Candy:
    '''
    A class to represent a Candy 

    Attributes: 
    ----------
    price: float 
        The price of a candy 
    ingredients: List[_ingredient]
        A list of the ingredients. 

    '''

    def __init__(self, price: float, ingredients: List[_Ingredient]) -> None:
        self.price = price 
        self.ingredients = ingredients

    def __str__(self) -> str:
        s = "candy--price-{}-ingredients-".format(str(self.price))
        for ingre in self.ingredients:
            s += str(ingre)
        return s 

